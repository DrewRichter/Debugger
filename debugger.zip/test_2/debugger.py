from functools import wraps
import json
from os import environ as env
from werkzeug.exceptions import HTTPException

from flask import Flask, render_template, url_for, request, redirect, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy import desc
from sqlalchemy import ForeignKey
from six.moves.urllib.parse import urlencode
app = Flask(__name__)
str= 'take4.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///{test}'.format(test=str) # three slashes for relative path. 4 for absolute
app.secret_key='J4jRI7vghWOxvDi3UeD2rrNhZtSao3gRQc8uTY7qDLCrvtmZm4TfzSgeNfZDBqOt00819'
db = SQLAlchemy(app)


class Todo(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    content= db.Column(db.String(200), nullable=False)
    completed = db.Column(db.Integer, default=0)
    date_created= db.Column(db.DateTime, default=datetime.utcnow)
    description = db.Column(db.Text)
    priority=db.Column(db.String(100))  # 0 for low 1 for mid 2 or above for high
    date_due = db.Column(db.DateTime)
    developer_name = db.Column(db.String(200))
    date_due_str = db.Column(db.String(100))
    def __repr__(self):
        return '<Task %r>' % self.id # everytime we create a new element it returns task and the id of the task created

class Edits(db.Model):
    edit_id=db.Column(db.Integer, primary_key=True, autoincrement=True)
    date_edited=db.Column(db.DateTime, default=datetime.utcnow)
    content = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    developer_name = db.Column(db.String(200))
    todo_id = db.Column(db.Integer, ForeignKey('todo.id'))
@app.route("/login/", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        if request.form["email_create"] =="" and request.form["password_create"] =="" and request.form["confirmation_create"] =="" and not request.form["email_login"] =="" and not request.form["password_login"] =="":
            print("1")
            email= request.form["email_login"]
            password = request.form['password_login']
            session["email"]=email
            session["password"]= password
        elif not request.form["email_create"] =="" and not request.form["password_create"] =="" and not request.form["confirmation_create"] =="" and request.form["email_login"] =="" and  request.form["password_login"] =="":
            print("2")
            if not request.form["password_create"] == request.form["confirmation_create"]:
                flash("Password and confirmation are different. Try again.")

            else:
                email = request.form["email_create"]
                password = request.form['password_create']
                session["email"] = email
                session["password"] = password
        else:
            print(request.form["email_login"])
            flash("You entered the incorrect or incomplete criteria. Please try again.")
        return redirect("/home/")
    else:
        return render_template("login.html")



@app.route("/home/", methods=['POST', 'GET'])
def home():
    if "email" in session:
        if request.method == "POST":
            if not request.form['select project'].trim() == "" and request.form['create project'].trim() == "":
                r= request.form['select project']
                redirect("/<r>") # work later on index
            elif  request.form['select project'].trim() == "" and not request.form['create project'].trim() == "":
                r= request.form['create project']
                with open("projects") as p:
                    data=json.load(p)
                    #data[]






        return render_template('homepage.html')
    else:
        return redirect("/login/")

@app.route("/", methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        task_content = request.form['content'] # content is the name of the text input in index.html
        task_description = request.form['description']
        task_priority=request.form['priority']
        task_developer_name=request.form['developer_name']
        task_due_date = request.form['due_date']
        datestring=""
        try:
            due_date = datetime.strptime(task_due_date.replace("T", " "), '%Y-%m-%d %H:%M')

            datestring= datetime.strftime(due_date,'%Y-%m-%dT%H:%M')



        except ValueError:
            due_date=None

        new_task = Todo(content=task_content, description=task_description, developer_name=task_developer_name, priority=task_priority, date_due=due_date, date_due_str=datestring)


        #try:
        db.session.add(new_task)


        db.session.commit()
        return redirect("/")
        #except:
            #return 'There was an issue adding your task'

    else:
        tasks=Todo.query.order_by(Todo.date_created).filter_by(completed=0).all()
        print(type(tasks))
        return render_template("index.html", tasks=tasks)
@app.route('/delete/<int:id>')
def delete(id):
    task = Todo.query.get_or_404(id)
    try:
        task.completed=1
        db.session.commit()
        return redirect('/')
    except:
        return 'There was a problem deleting that task'
@app.route('/fixed/')
def fixed():
    tasks = Todo.query.order_by(Todo.date_created).filter_by(completed=1).all()
    return render_template('fixed.html', tasks=tasks)
@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    task = Todo.query.get_or_404(id)
    if request.method =='POST':
        print("request method post")



        description = ""


        if not task.priority == request.form['priority']:
            description = 'Priority: {old} --> {new}'.format(old=task.priority, new=request.form['priority'])
        if not task.date_due == request.form['due_date'] and not description == "":
            description += '@0819newtabDate due: {old} --> {new}'.format(old=task.date_due, new=request.form['due_date'])
        elif not task.date_due == request.form['due_date']:
            description += 'Date due: {old} --> {new}'.format(old=task.date_due, new=request.form['due_date'])  #This logic is all messed up but things are okay
        else:
            description=description
        if not task.description == request.form['description'] and not description == "":
                description += '@0819newlinePrevious Description: @0819newline' + task.description + '@0819newlineNew Description:@0819newline ' + \
                               request.form['description']
        if not task.description == request.form['description'] and description == "":
                description += 'Previous Description: @0819newline' + task.description + 'New Description:@0819newline ' + \
                               request.form['description']
        if not description == "":
            new_edit=Edits(description=description, developer_name = request.form['developer_name'], content=task.content, todo_id=task.id)
            db.session.add(new_edit)

        task.description = request.form['description']
        task.date_due = datetime.strptime(request.form['due_date'], '%Y-%m-%dT%H:%M')
        task.priority = request.form['priority']
       # try:


        db.session.commit()



        return redirect('/')
       # except:
            #return "There was an issue updating your task"
    else:
        return render_template('update.html', task=task)
@app.route('/edit/<int:id>')
def edit(id):
    edits=Edits.query.filter_by(todo_id=id).all()
    return render_template('edit.html', edits=edits)
@app.route('/re-open/<int:id>', methods=['GET', 'POST'])
def re_open(id):
    task = Todo.query.get_or_404(id)
    if request.method == 'POST':
        task.description=request.form['description']
        task.date_due = datetime.strptime(request.form['due_date'], '%Y-%m-%dT%H:%M')
        task.priority = request.form['priority']
        description= "Bug Re-Opened: "+ datetime.strftime(datetime.utcnow(), '%Y-%m-%dT%H:%M')+" By "+request.form['developer_name'] +"@0819newlineReason for re-open:@0819newline" + task.description
        new_edit=Edits(description=description, developer_name = request.form['developer_name'], content=task.content, todo_id=task.id)
        task.completed = 0
        db.session.add(new_edit)
        db.session.commit()

        return redirect('/')
    else:
        return render_template('re_open.html', task=task)




if __name__ == "__main__":
    app.run(debug=True)